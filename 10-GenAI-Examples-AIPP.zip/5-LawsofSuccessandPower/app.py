import streamlit as st

st.markdown("""
# Laws of Power
- Never Outshine the Master 🌟
- Always Say Less Than Necessary 🤐
- Keep Your Friends Close, but Your Enemies Closer 👥🔍
- Conceal Your Intentions 🙅‍♂️💭
- Crush Your Enemy Totally 💥👊
- Use Absence to Increase Respect and Honor 🚶‍♂️👀
- Get Others to Do the Work for You 👥💪
- Think as You Like, but Behave Like Others 🤔👥
- Play to People's Fantasies 🌟🧚‍♀️
- Avoid Stepping on the Toes of Those Above You 🚶‍♂️👞

# Laws of Success
- Set Clear Goals and Visualize Them 🎯🖼️
- Take Action and Persevere 💪🚀
- Continuously Learn and Adapt 📚🔄
- Build Strong Relationships and Networks 👥🤝
- Embrace Failure and Learn from It ❌📖
- Take Ownership of Your Actions and Results 🙋‍♂️📊
- Stay Focused and Prioritize 🎯🔝
- Maintain a Positive Attitude and Mindset 😄🌈
- Practice Discipline and Consistency 📆🔁
- Celebrate Milestones and Reward Yourself 🎉🏆

## Intersection List
- Laws of Power:
  - Never Outshine the Master
  - Always Say Less Than Necessary
  - Keep Your Friends Close, but Your Enemies Closer
  - Conceal Your Intentions
  - Crush Your Enemy Totally
  - Use Absence to Increase Respect and Honor
  - Get Others to Do the Work for You
  - Think as You Like, but Behave Like Others
  - Play to People's Fantasies
  - Avoid Stepping on the Toes of Those Above You

- Laws of Success:
  - Set Clear Goals and Visualize Them
  - Take Action and Persevere
  - Continuously Learn and Adapt
  - Build Strong Relationships and Networks
  - Embrace Failure and Learn from It
  - Take Ownership of Your Actions and Results
  - Stay Focused and Prioritize
  - Maintain a Positive Attitude and Mindset
  - Practice Discipline and Consistency
  - Celebrate Milestones and Reward Yourself

## Heatmap of Dimensions
- Success:
  - Goals
  - Action
  - Learning
  - Relationships
  - Failure
  - Ownership
  - Focus
  - Attitude
  - Discipline
  - Milestones

- Power:
  - Master
  - Necessary
  - Enemies
  - Intentions
  - Enemy
  - Absence
  - Work
  - Behave
  - Fantasies
  - Above
""")

import nltk
from nltk.corpus import wordnet as wn

nltk.download('wordnet')

# Laws of Power
laws_of_power = [
    ("Never Outshine the Master", "Avoid overshadowing or showing up your superiors, as it can lead to jealousy and resentment."),
    ("Always Say Less Than Necessary", "Control your words and reveal only what is necessary, as excessive talking can lead to mistakes or giving away too much information."),
    ("Keep Your Friends Close, but Your Enemies Closer", "Stay aware of your enemies and their actions, as understanding their motives and intentions can help you anticipate and counter their moves."),
    ("Conceal Your Intentions", "Keep your true intentions hidden to maintain an element of surprise and gain an advantage in negotiations or conflicts."),
    ("Crush Your Enemy Totally", "When facing opposition, eliminate any chance of retaliation or future threats by decisively defeating your enemies."),
    ("Use Absence to Increase Respect and Honor", "Create a sense of importance and value by occasionally withdrawing from the spotlight, making others appreciate your presence more."),
    ("Get Others to Do the Work for You", "Delegate tasks and responsibilities to others, allowing you to focus on higher-level strategies and maintain control over the outcome."),
    ("Think as You Like, but Behave Like Others", "Blend in with your surroundings and adapt to social norms, as deviating too much from the norm can lead to isolation or suspicion."),
    ("Play to People's Fantasies", "Appeal to people's desires and aspirations, tapping into their fantasies to gain their support or influence their decisions."),
    ("Avoid Stepping on the Toes of Those Above You", "Be cautious not to offend or challenge those in positions of power, as it can lead to negative consequences for your own advancement.")
]

# Laws of Success
laws_of_success = [
    ("Set Clear Goals and Visualize Them", "Define specific and achievable goals, and visualize yourself achieving them to increase motivation and focus."),
    ("Take Action and Persevere", "Act upon your goals and persist through challenges and setbacks, as consistent effort is essential for success."),
    ("Continuously Learn and Adapt", "Embrace a growth mindset and seek knowledge and new skills, as the ability to adapt to changing circumstances is crucial for success."),
    ("Build Strong Relationships and Networks", "Cultivate meaningful connections with others, as strong relationships and networks can provide support, opportunities, and valuable insights."),
    ("Embrace Failure and Learn from It", "See failure as a learning opportunity and use it to improve and grow, as resilience and the ability to bounce back are vital for success."),
    ("Take Ownership of Your Actions and Results", "Accept responsibility for your choices and outcomes, as taking ownership empowers you to make necessary changes and drive your own success."),
    ("Stay Focused and Prioritize", "Concentrate your time and energy on the most important tasks and goals, avoiding distractions that can hinder progress."),
    ("Maintain a Positive Attitude and Mindset", "Cultivate optimism and resilience, as a positive attitude can help you overcome challenges and attract opportunities."),
    ("Practice Discipline and Consistency", "Develop self-discipline and maintain consistent effort towards your goals, as small daily actions can lead to significant long-term success."),
    ("Celebrate Milestones and Reward Yourself", "Acknowledge and celebrate your achievements along the way, as rewarding yourself reinforces positive behavior and motivates further success.")
]

# Intersection List
intersection_list = [law[0] for law in laws_of_power if law[0] in [law[0] for law in laws_of_success]]

# Heatmap of Dimensions
success_words = ['Goals', 'Action', 'Learning', 'Relationships', 'Failure', 'Ownership', 'Focus', 'Attitude', 'Discipline', 'Milestones']
power_words = ['Master', 'Necessary', 'Enemies', 'Intentions', 'Enemy', 'Absence', 'Work', 'Behave', 'Fantasies', 'Above']

heatmap = []
for word in success_words:
    if word in power_words:
        heatmap.append(word)

# Print the laws of power
print("## Laws of Power")
for law in laws_of_power:
    print(f"- {law[0]} {law[1]}")

# Print the laws of success
print("\n## Laws of Success")
for law in laws_of_success:
    print(f"- {law[0]} {law[1]}")

# Print the intersection list
print("\n## Intersection List")
for law in intersection_list:
    print(f"- {law}")

# Print the heatmap of dimensions
print("\n## Heatmap of Dimensions")
print("- Success:")
for word in success_words:
    if word in heatmap:
        print(f"  - {word}")
print("\n- Power:")
for word in power_words:
    if word in heatmap:
        print(f"  - {word}")


