---
title: MixtureOfExpertsMOEAnalysisForLLMRoles
emoji: 😻
colorFrom: yellow
colorTo: green
sdk: streamlit
sdk_version: 1.25.0
app_file: app.py
pinned: false
license: mit
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
