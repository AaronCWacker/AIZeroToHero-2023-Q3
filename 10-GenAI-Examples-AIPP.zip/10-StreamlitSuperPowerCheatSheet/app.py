import streamlit as st
import pandas as pd
import random

# Magic commands
#st.set_page_config(page_title='Streamlit Super Power Cheat Sheet - Gamified')
#st.set_option('deprecation.showfileUploaderEncoding', False)

# Define player cards
player1 = [{'Word': 'Strategy', 'Definition': 'A plan of action designed to achieve a long-term or overall aim.'},
           {'Word': 'Economics', 'Definition': 'The branch of knowledge concerned with the production, consumption, and transfer of wealth.'},
           {'Word': 'Industry', 'Definition': 'Economic activity concerned with the processing of raw materials and manufacture of goods in factories.'}]

player2 = [{'Word': 'Manufacturing', 'Definition': 'The making of articles on a large scale using machinery.'},
           {'Word': 'Transportation', 'Definition': 'The action of transporting someone or something or the process of being transported.'},
           {'Word': 'Community', 'Definition': 'A group of people living in the same place or having a particular characteristic in common.'}]

# Create dataframes for each player card
df_player1 = pd.DataFrame(player1)
df_player2 = pd.DataFrame(player2)

# Merge the dataframes on word matches
df_matches = pd.merge(df_player1, df_player2, on='Word')

# Display the merged dataframe
st.dataframe(df_matches)

# Display the word match count
match_count = df_matches.shape[0]
st.write(f'Number of word matches: {match_count}')

# Display a random word match
if match_count > 0:
    random_match = df_matches.iloc[random.randint(0, match_count-1)]
    st.write(f'Random match: {random_match["Word"]}')
    st.write(f'{random_match["Definition_x"]}')
    st.write(f'{random_match["Definition_y"]}')
else:
    st.write('No word matches')

# Emoji graphics
AI = '🤖'
DATA = '📊'
EMOJIS = ['🤣', '😂', '😜', '🤪', '😎', '🤔']

# strategy data
import pandas as pd

# Define the strategy classifications and their definitions
strategy_data = [
    {'Classification': 'Economic', 'Definition': '💰 The branch of knowledge concerned with the production, consumption, and transfer of wealth.'},
    {'Classification': 'Industry', 'Definition': '🏭 Economic activity concerned with the processing of raw materials and manufacture of goods in factories.'},
    {'Classification': 'Manufacturing', 'Definition': '🏭 The making of articles on a large scale using machinery.'},
    {'Classification': 'Development', 'Definition': '🏗️ The process of growth, progress, or realization of goals.'},
    {'Classification': 'Transport', 'Definition': '🚗 The movement of people, goods, or materials from one place to another.'},
    {'Classification': 'Income', 'Definition': '💸 The money received by a person, company, or country for work, services, or investment.'},
    {'Classification': 'Market', 'Definition': '📈 A regular gathering of people for the purchase and sale of goods.'},
    {'Classification': 'Network', 'Definition': '🌐 A group of interconnected people, companies, or devices that share information or resources.'},
]

st.markdown("""
  Classification                                         Definition
0       Economic  💰 The branch of knowledge concerned with the p...
1        Industry  🏭 Economic activity concerned with the process...
2   Manufacturing  🏭 The making of articles on a large scale usin...
3     Development  🏗️ The process of growth, progress, or realiz...
4       Transport  🚗 The movement of people, goods, or materials ...
5          Income  💸 The money received by a person, company, or ...
6          Market  📈 A regular gathering of people for the purcha...
7         Network  🌐 A group of interconnected people, companies,...
""")

# Create a dataframe from the strategy data
df_strategy = pd.DataFrame(strategy_data)

# Display the dataframe
print(df_strategy)


# Example AI data
ai_data = {'accuracy': 0.89, 'precision': 0.72, 'recall': 0.64, 'f1': 0.68}

# One-liner functions
st.write(f"{AI} I'm sorry Dave, I'm afraid I can't do that.")
st.dataframe(pd.DataFrame(ai_data, index=['Model']))
st.table(pd.DataFrame(ai_data, index=['Model']))
st.json({'foo':'bar', 'fu':'ba', 'ai_data': ai_data})
st.metric(label="Model Accuracy", value=ai_data['accuracy'], delta=0.02)
st.button('Hit me ' + random.choice(EMOJIS))
st.checkbox('Tickle me ' + random.choice(EMOJIS))
st.radio('Choose your favorite ' + DATA, ['Bar chart', 'Pie chart', 'Line chart'])
st.selectbox('Select your ' + DATA, ['Sales', 'Expenses', 'Profits'])
st.multiselect('Pick your favorite ' + DATA + 's', ['Revenue', 'Profit', 'Loss'])
st.slider('Slide to ' + DATA, min_value=0, max_value=10)
st.select_slider('Slide to select your favorite ' + DATA, options=[1,2,3,4])
st.text_input('Enter some ' + DATA)
st.number_input('Enter a random ' + DATA + ' value')
st.text_area('Type something ' + random.choice(EMOJIS) + ' here')
st.date_input('Choose a ' + random.choice(['start', 'end']) + ' ' + DATA + ' date')
st.time_input('What time is it? ' + random.choice(EMOJIS))
st.file_uploader('Upload your favorite ' + DATA + ' ' + random.choice(EMOJIS))
st.color_picker('Pick a ' + DATA + ' ' + random.choice(EMOJIS))