---
title: 💾PersistentDatasetMemoryGradio
emoji: 💾🧠
colorFrom: yellow
colorTo: blue
sdk: gradio
sdk_version: 2.4.2
app_file: app.py
pinned: false
license: mit
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces#reference
